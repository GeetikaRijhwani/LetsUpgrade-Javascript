//1 - Program to search for a particular character in a string

console.log(`****************Program 1**************`);
let str = "GeetikaString";
let op = str.search('a');
console.log(`Required character "a" in String "GeetikaString" is located at ${op}th position if first letter is counted from 0`);

//2 - Program to convert minutes to seconds

console.log(`****************Program 2**************`);
let min = 30;
let sec = min*60;
console.log(`${min} minutes are equivalent to ${sec} seconds`);

//3 - Program to search for a element in a array of strings

console.log(`****************Program 3**************`);
let DataArr = ["laptop", "mouse", "keyboard", "monitor", "camera", "mobile"];
console.log(`Input array "${DataArr}"`)
console.log(`Elements to be searched "camera"`);
let ele = "camera";
for(let i=0; i<DataArr.length; i++)
{
       if(ele == DataArr[i]){
        console.log(`"camera" is at ${i} position if first element is counted from 0`);
    }
}

//4 - Program to display only elements containing 'a' in them from a array

console.log(`****************Program 4**************`);
let DataAr = ["laptop", "mouse", "keyboard", "monitor", "camera", "mobile"];
console.log(`Input array "${DataAr}"`)
console.log(`Elements from array containing only "a"`);
for(let i=0; i<DataAr.length; i++)
{
    let pos = DataAr[i].search('a');
    if(pos>=0){
        console.log(DataAr[i]);
    }
}

//5 - Print an array in reverse order

console.log(`****************Program 5**************`);
let DataArrr = ["laptop", "mouse", "keyboard", "monitor", "camera", "mobile"];
console.log(`Input array`);
for(let i=0; i<DataArrr.length; i++)
{
    console.log(DataArrr[i]);
}
console.log(`Array in Reverse Order`);
for(let i=DataArrr.length-1; i>=0; i--)
{
    console.log(DataArrr[i]);
}